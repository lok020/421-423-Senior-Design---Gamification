# Sudoku

Youtube link to series: https://www.youtube.com/playlist?list=PLfRK1c45b0igPDONJjhm898mZdEWwNu5V

Play Store link: https://play.google.com/store/apps/details?id=com.marcellelek.sudoku

You need two libraries to work:
  - android-support-v7-appcompat
  - android-support-v7-gridlayout
  
If you like my work buy me a beer at paypal account: marcellkristof.elek@gmail.com
